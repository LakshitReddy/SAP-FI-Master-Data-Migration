
# SAP FI Master Data Migration – ETL Project

## Project Overview

This project simulates the migration of General Ledger (G/L)
master data from a legacy ERP system into an
SAP S/4HANA-ready target structure.

The project demonstrates data extraction, profiling,
cleansing, transformation, SQL validation and reconciliation.

## Technology Stack

- Python
- Pandas
- SQLite
- SQL
- CSV

## Project Workflow

1. Extract legacy G/L account data from CSV.
2. Profile source data for quality issues.
3. Clean and transform source records.
4. Map legacy account types to target values.
5. Separate valid and rejected records.
6. Load valid records into SQLite staging.
7. Execute SQL validation queries.
8. Generate migration reconciliation report.

## Data Quality Rules

- Identify duplicate G/L account numbers.
- Check mandatory descriptions.
- Validate account types.
- Check company code assignments.
- Remove unwanted spaces.

## Sample Migration Results

| Metric | Result |
|---|---:|
| Source Records | 12 |
| Valid Records | 8 |
| Rejected Records | 4 |
| Staging Records | 8 |
| Success Rate | 66.67% |
| Reconciliation | PASS |

## Output Files

- valid_gl_accounts.csv
- rejected_gl_accounts.csv
- migration_reconciliation_report.csv

## Important Note

This is an educational simulation of an SAP FI
data migration process. It does not connect to a live
SAP S/4HANA system or perform an actual SAP DMC upload.

The target structure is illustrative and should be
adapted to the relevant SAP migration object template
before a real migration.

## Author

Lakshit Reddy

SAP FI Data Migration | Python | SQL | ETL
